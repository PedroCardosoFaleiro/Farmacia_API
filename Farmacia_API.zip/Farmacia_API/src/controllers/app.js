const express = require('express');
const medicamentosRouter = require('./controllerMedicamentos');
const fornecedoresRouter = require('./controllerFornecedores');
const clientesRouter = require('./controllerClientes');
const vendasRouter = require('./controllerVendas')
const cors = require('cors');
const app = express();
app.use(cors()); 
app.use('/api', medicamentosRouter.server); 
app.use('/api', fornecedoresRouter.server); 
app.use('/api', clientesRouter.server); 
app.use('/api', vendasRouter.server); 
app.listen(3000, () => {
    console.log('O servidor está funcionando! :D');
});